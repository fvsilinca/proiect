# KEAP candle shop - website - HTML, CSS, JavaScript

Website for an online candle shop, using HTML, CSS and JavaScript.
